DHARANI BIRTHDAY WEBSITE — STANDALONE VERSION ❤️

This version has the MP3 and all 3 photos embedded directly inside index.html.
You do NOT need the assets folder.

How to run:
1. Extract the ZIP.
2. Open index.html in Chrome or Edge.
3. On the first page, press/hold the bow/arrow area and release.
4. The music should start after that first touch.
5. If music does not start, tap the "🎵 Tap for Music" button in the top-right.
6. Continue through the pages.

Because the media is embedded, do not edit or rename index.html.
